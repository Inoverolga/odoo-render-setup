{
    'name': 'Inventory Import',
    'version': '1.0',
    'summary': 'Import inventory data from API',
    'depends': ['base'],
    'data': [
        'views/inventory_views.xml',
    ],
    'installable': True,
}